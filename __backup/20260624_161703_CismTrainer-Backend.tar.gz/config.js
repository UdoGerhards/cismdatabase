// config.js
import dotenv from "dotenv";

dotenv.config();

const isJest = () => {
  return process.env.JEST_WORKER_ID !== undefined;
};

const db_connection = "mongodb+srv://udogerhards:0OwBTRtnBGjP6NMb@cimsexams.zcovvz2.mongodb.net/?appName=cimsexams&family=4";
let db_name = "cism";


const isMock = () =>  {
  return process.env.npm_lifecycle_event == "mock"?true:false;
}

if (isJest() || isMock()) {
  db_name = "cism_test";
}

export const DB_CONNECTION =  db_connection;
export const DB_NAME = db_name;
export const GEMINI_API_KEY = "AIzaSyAR8NkTHrrLwfn-hniIO-DxhQhwEi1q-bs";

if (!process.env.JWT_SECRET) {
  throw new Error("JWT_SECRET is not defined in environment variables");
}

export const JWT_SECRET = process.env.JWT_SECRET;
export const TOKEN_EXPIRATION = process.env.TOKEN_EXPIRATION || "1h";
